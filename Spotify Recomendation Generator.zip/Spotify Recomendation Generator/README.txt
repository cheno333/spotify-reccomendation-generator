Setting Up The Needed File:
	- Open https://developer.spotify.com/dashboard and login
	- Press "Create app"
	- Fill in the app info
		- The name and description don't matter
		- For the "Redirect URIs" section, enter "http://localhost:8888/callback" and add it
		- Check the final box (TOS agreement, etc.) and save the app
	- Once redirected to the app's dasboard, open the settings page
	- Open the spotify_credentials.txt file
	- Copy the Client ID from the app's dashboard over to the txt file
	- Press "View client secret", and copy that over as well


At this point, the txt file should look like the following:

CLIENT_ID=X
CLIENT_SECRET=Y
REDIRECT_URI=http://localhost:8888/callback

Make sure the Client ID is pasted over X, and  the Client Secret is pasted over Y
It's very important that there are NO spaces on each line ("CLIENT_ID= X" is not in the correct format)


You're done! Now just open a command prompt, run srg.py, and then drag spotify_credentials.txt onto the program.

-CJ


Apologies if the instructions are unclear or the formatting is weird, It's 4am and I haven't slept in 2 days :)
	