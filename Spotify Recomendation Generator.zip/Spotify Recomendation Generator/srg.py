import spotipy
from spotipy.oauth2 import SpotifyOAuth
import os
import random

def load_credentials(file_path):
    credentials = {}
    with open(file_path, 'r') as file:
        for line in file:
            key, value = line.strip().split('=')
            credentials[key] = value
    return credentials

def authenticate_spotify(credentials):
    sp = spotipy.Spotify(auth_manager=SpotifyOAuth(
        client_id=credentials['CLIENT_ID'],
        client_secret=credentials['CLIENT_SECRET'],
        redirect_uri=credentials['REDIRECT_URI'],
        scope='playlist-modify-public'
    ))
    return sp

def get_track_id(sp, track_name, artist_name):
    query = f"track:{track_name} artist:{artist_name}"
    results = sp.search(q=query, limit=1, type='track')
    if results['tracks']['items']:
        return results['tracks']['items'][0]['id']
    else:
        print(f"Track '{track_name}' by '{artist_name}' not found on Spotify.")
        return None

def get_artist_top_track(sp, artist_name):
    results = sp.search(q=f"artist:{artist_name}", limit=1, type='artist')
    if results['artists']['items']:
        artist_id = results['artists']['items'][0]['id']
        top_tracks = sp.artist_top_tracks(artist_id)['tracks']
        if top_tracks:
            return top_tracks[0]['id']
    print(f"Artist '{artist_name}' not found or has no top tracks on Spotify.")
    return None

def get_similar_tracks(sp, seed_ids, limit=10):
    seed_tracks = random.sample(seed_ids, min(len(seed_ids), 5))
    recommendations = sp.recommendations(seed_tracks=seed_tracks, limit=limit)
    return [track['id'] for track in recommendations['tracks']]

def create_playlist(sp, user_id, track_ids):
    playlist = sp.user_playlist_create(user=user_id, name="Generated Recomendations", public=True)
    sp.user_playlist_add_tracks(user=user_id, playlist_id=playlist['id'], tracks=track_ids)
    return playlist['external_urls']['spotify']

def main():
    file_path = input("Please enter the path to your Spotify credentials file: ").strip()
    
    if not os.path.exists(file_path):
        print("File not found. Please check the path and try again.")
        return
    
    credentials = load_credentials(file_path)
    
    sp = authenticate_spotify(credentials)
    user_id = sp.me()['id']
    
    print(f"Authenticated as {user_id}. Now you can create a playlist.")
    
    num_inputs = int(input("How many songs/artists do you want to input? (1-5): "))
    seed_ids = []
    
    for i in range(num_inputs):
        input_type = input(f"Do you want to input a 'song' or an 'artist' for input {i+1}? ").strip().lower()
        if input_type == 'song':
            track_input = input(f"Enter song {i+1} and artist (e.g., 'Song - Artist'): ").strip()
            if ' - ' in track_input:
                track_name, artist_name = track_input.split(' - ')
                track_name, artist_name = track_name.strip(), artist_name.strip()
                track_id = get_track_id(sp, track_name, artist_name)
                if track_id:
                    seed_ids.append(track_id)
            else:
                print(f"Invalid input format for '{track_input}'. Expected format: 'Song - Artist'")
        elif input_type == 'artist':
            artist_name = input(f"Enter artist name {i+1}: ").strip()
            top_track = get_artist_top_track(sp, artist_name)
            if top_track:
                seed_ids.append(top_track)
        else:
            print(f"Invalid input type '{input_type}'. Expected 'song' or 'artist'")
    
    if not seed_ids:
        print("No valid inputs found. Exiting.")
        return
    
    num_songs_in_playlist = int(input("How many songs do you want in the playlist? (1-50): "))
    
    similar_track_ids = get_similar_tracks(sp, seed_ids, limit=num_songs_in_playlist*2)
    random.shuffle(similar_track_ids)
    top_similar_track_ids = similar_track_ids[:num_songs_in_playlist]
    
    playlist_url = create_playlist(sp, user_id, top_similar_track_ids)
    
    print(f"Playlist created: {playlist_url}")

if __name__ == "__main__":
    main()
